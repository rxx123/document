# wechat-tabBar_component
#### 使用说明
下载后直接通过微信小程序导入page-component文件夹
